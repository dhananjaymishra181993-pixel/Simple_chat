// tests/auth.test.js
const request = require('supertest');
const { app, mongoose, User, Message } = require('../server');

describe('Auth and messages', () => {
  beforeAll(async () => {
    // wait for mongoose to connect
    const max = 20;
    let i = 0;
    while (mongoose.connection.readyState !== 1 && i < max) {
      // eslint-disable-next-line no-await-in-loop
      await new Promise(r => setTimeout(r, 200));
      i++;
    }
    // clear collections
    await User.deleteMany({});
    await Message.deleteMany({});
  });

  afterAll(async () => {
    try {
      await mongoose.connection.db.dropDatabase();
    } catch (e) {
      // ignore
    }
    await mongoose.disconnect();
  });

  test('register, login, me endpoints and message history', async () => {
    // register userA
    await request(app)
      .post('/api/register')
      .send({ username: 'userA', password: 'pass' })
      .expect(200);

    // login userA
    const loginA = await request(app)
      .post('/api/login')
      .send({ username: 'userA', password: 'pass' })
      .expect(200);

    const cookieA = loginA.headers['set-cookie'];
    expect(cookieA).toBeDefined();

    // call /api/me with cookie
    const meA = await request(app)
      .get('/api/me')
      .set('Cookie', cookieA)
      .expect(200);

    expect(meA.body.username).toBe('userA');

    // register userB
    await request(app)
      .post('/api/register')
      .send({ username: 'userB', password: 'pass' })
      .expect(200);

    // login userB
    const loginB = await request(app)
      .post('/api/login')
      .send({ username: 'userB', password: 'pass' })
      .expect(200);

    const cookieB = loginB.headers['set-cookie'];
    expect(cookieB).toBeDefined();

    // find users from DB
    const a = await User.findOne({ username: 'userA' }).lean();
    const b = await User.findOne({ username: 'userB' }).lean();

    // insert messages between A and B
    const docs = [];
    for (let i = 0; i < 5; i++) {
      docs.push({ from: a._id, to: b._id, text: `A->B ${i}` });
      docs.push({ from: b._id, to: a._id, text: `B->A ${i}` });
    }
    await Message.insertMany(docs);

    // fetch messages from A's perspective with cookieA (should return messages between A and B)
    const res = await request(app)
      .get('/api/messages')
      .query({ withUserId: b._id.toString(), limit: 20 })
      .set('Cookie', cookieA)
      .expect(200);

    expect(res.body.messages).toBeDefined();
    expect(res.body.messages.length).toBeGreaterThanOrEqual(10);
    // check the content shape
    const first = res.body.messages[0];
    expect(first.text).toBeDefined();

    // test mark-read endpoint: mark B->A messages as read (using A's cookie)
    const mark = await request(app)
      .post('/api/mark-read')
      .query({ withUserId: b._id.toString() })
      .set('Cookie', cookieA)
      .expect(200);

    expect(typeof mark.body.marked).toBe('number');
  });
});
